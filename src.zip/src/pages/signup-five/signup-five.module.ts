import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SignupFivePage } from './signup-five';

@NgModule({
  declarations: [
    SignupFivePage,
  ],
  imports: [
    IonicPageModule.forChild(SignupFivePage),
  ],
})
export class SignupFivePageModule {}
