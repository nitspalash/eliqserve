import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SignupThreePage } from './signup-three';

@NgModule({
  declarations: [
    SignupThreePage,
  ],
  imports: [
    IonicPageModule.forChild(SignupThreePage),
  ],
})
export class SignupThreePageModule {}
