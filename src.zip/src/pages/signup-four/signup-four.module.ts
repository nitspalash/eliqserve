import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SignupFourPage } from './signup-four';

@NgModule({
  declarations: [
    SignupFourPage,
  ],
  imports: [
    IonicPageModule.forChild(SignupFourPage),
  ],
})
export class SignupFourPageModule {}
