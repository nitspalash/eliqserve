import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SellerorderdetailsPage } from './sellerorderdetails';

@NgModule({
  declarations: [
    SellerorderdetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(SellerorderdetailsPage),
  ],
})
export class SellerorderdetailsPageModule {}
