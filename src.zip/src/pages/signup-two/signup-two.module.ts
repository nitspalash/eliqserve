import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SignupTwoPage } from './signup-two';

@NgModule({
  declarations: [
    SignupTwoPage,
  ],
  imports: [
    IonicPageModule.forChild(SignupTwoPage),
  ],
})
export class SignupTwoPageModule {}
