import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EarningreportPage } from './earningreport';

@NgModule({
  declarations: [
    EarningreportPage,
  ],
  imports: [
    IonicPageModule.forChild(EarningreportPage),
  ],
})
export class EarningreportPageModule {}
