import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SignuponePage } from './signupone';

@NgModule({
  declarations: [
    SignuponePage,
  ],
  imports: [
    IonicPageModule.forChild(SignuponePage),
  ],
})
export class SignuponePageModule {}
