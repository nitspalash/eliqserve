
export const Config = {
    baseUrl:'http://111.93.169.90/team6/alcohol/api/'
    // baseUrl:'http://192.168.1.118/team6/alcohol/api/'
}