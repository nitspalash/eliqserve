import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams,AlertController } from 'ionic-angular';
import {AuthProvider} from '../../providers/auth-service/authservice'
/**
 * Generated class for the SearchResultDetailsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-search-result-details',
  templateUrl: 'search-result-details.html',
})
export class SearchResultDetailsPage {
pamater:any;
detailArray:any=[];
imageLink:any;
addCartSet:any;
userId:any;
loginuser:any;
  constructor(public navCtrl: NavController, public navParams: NavParams,
  public authProvider:AuthProvider,
public alertCtrl:AlertController) {
    this.pamater=navParams.get('param')
    console.log(this.pamater)


let dataSet={
  "prod_id":this.pamater
}

    this.authProvider.productDetails(dataSet).subscribe(res=>{
      console.log(res);
     
      let details = res
      if(details.Ack == 1){
        console.log('hello')
        
      this.detailArray=details.product
      this.imageLink=details.image_link
      
     
      console.log (this.imageLink);
      

      }
  });


  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SearchResultDetailsPage');
  }
  addcart(prodId)
  {
    console.log (prodId)
    // alert('Your product added successfully');


    if(JSON.parse(localStorage.getItem('userDetails')))
    {
      this.loginuser = JSON.parse(localStorage.getItem('userDetails')); 
      this.userId=this.loginuser.id
      // console.log (localStorage.getItem('userDetails'))
      console.log ( this.userId)
    }

    this.addCartSet={
      "user_id":this.userId,
      "prod_id":prodId
    }
    console.log(this.addCartSet)

    this.authProvider.addToCart(this.addCartSet).subscribe(res=>{
      console.log(res);
     
      let details = res
    const alert = this.alertCtrl.create({
      title: 'Cart Added Successfully!',
      buttons: ['OK']
    });
    alert.present();
    this.navCtrl.push('CartPage')
  });
  }
}
