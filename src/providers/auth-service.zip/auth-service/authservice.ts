import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Headers, Http, Response, RequestOptions, RequestMethod, Request } from '@angular/http';
import 'rxjs/add/operator/map';
import { HttpClient } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
import { LoadingController } from 'ionic-angular';
import { Config } from './../../config';

@Injectable()
export class AuthProvider {
  apiUrl = Config.baseUrl;
  constructor(
      public http: HttpClient , public loadingCtrl: LoadingController
    ) {
    
    console.log(Config.baseUrl)
      }
    

    login(data:object):Observable<any>{
      console.log(data);
       return this.http.post(this.apiUrl +'users/token.json',data).map((res:Response)=>{
         return res;
       });
     }

     signup(data:object):Observable<any>{
      console.log(data);
       return this.http.post(this.apiUrl +'users/register.json',data).map((res:Response)=>{
         return res;
       });
     }

forgotPassword(data:object):Observable<any>{
  console.log(data);
   return this.http.post(this.apiUrl +'users/forgotpassword.json',data).map((res:Response)=>{
     return res;
   });
 }



 changePassword(data:object):Observable<any>{
  console.log(data);
   return this.http.post(this.apiUrl +'users/changepassword.json',data).map((res:Response)=>{
     return res;
   });
 }
    
 
 editProfile(data:object):Observable<any>{
  console.log(data);
   return this.http.post(this.apiUrl +'users/edituserprofile.json',data).map((res:Response)=>{
     return res;
   });
 }

 verifyOtp(data:object):Observable<any>{
  console.log(data);
   return this.http.post(this.apiUrl +'users/verifyotp.json',data).map((res:Response)=>{
     return res;
   });
 }





 categoryListing ()
 {
   return this.http.get(this.apiUrl +'products/categorylisting.json').map((res: Response) => {
     return res;
   });
 }
 
listProduct(data:object):Observable<any>{
  console.log(data);
   return this.http.post(this.apiUrl +'products/listproduct.json',data).map((res:Response)=>{
     return res;
   });
 }
 productDetails(data:object):Observable<any>{
  console.log(data);
   return this.http.post(this.apiUrl +'products/productdetails.json',data).map((res:Response)=>{
     return res;
   });
 }

 addToCart(data:object):Observable<any>{
  console.log(data);
   return this.http.post(this.apiUrl +'products/addcart.json',data).map((res:Response)=>{
     return res;
   });
 }

 cartList(data:object):Observable<any>{
  console.log(data);
   return this.http.post(this.apiUrl +'products/cart.json',data).map((res:Response)=>{
     return res;
   });
 }



    }